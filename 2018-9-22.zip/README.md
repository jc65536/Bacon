# Bacon
Frontend for Brian's Kevin Bacon searcher
